DELETE FROM booking
WHERE 
    booking_id = 1         
    AND user_tel = '0812345678';
