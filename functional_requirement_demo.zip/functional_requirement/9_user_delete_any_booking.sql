DELETE FROM booking
WHERE 
    booking_id IN (1, 3, 5, 7);